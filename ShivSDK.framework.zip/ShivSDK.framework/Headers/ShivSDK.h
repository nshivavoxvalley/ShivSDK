//
//  ShivSDK.h
//  ShivSDK
//
//  Created by ShivaPrasad on 26/02/20.
//  Copyright © 2020 ShivaPrasad. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ShivSDK.
FOUNDATION_EXPORT double ShivSDKVersionNumber;

//! Project version string for ShivSDK.
FOUNDATION_EXPORT const unsigned char ShivSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ShivSDK/PublicHeader.h>

#import <ShivSDK/ShivLog.h>
